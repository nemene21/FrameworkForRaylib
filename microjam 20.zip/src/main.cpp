#include <framework.hpp>
#include <scenes/game.hpp>

int main() {
    Framework::init("Out of Space", {180, 180}, 3);

    new GameScene();
    SceneManager::set_scene("game_scene");

    Framework::run();
    return 0;
}

