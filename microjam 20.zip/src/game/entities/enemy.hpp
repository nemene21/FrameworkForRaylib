#ifndef ENEMY_H
#define ENEMY_H
#include "ship.hpp"

class Enemy: public Ship {
public:
    Enemy(Vector2 pos, std::string texture);
    void hit(Vector2 knockback);
};

#endif