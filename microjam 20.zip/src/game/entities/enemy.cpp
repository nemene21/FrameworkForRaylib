#include "enemy.hpp"

Enemy::Enemy(Vector2 pos, std::string texture): Ship(pos, texture, 3) {
    area_comp->add_layer((int)AreaIndex::ENEMY);
    join_group("Enemy");

    health_comp->died_signal.connect([this](Entity* ent) {
        AudioManager::play_sfx("enemy_die.mp3", 1, 1, 0.1, 0.8);
    });
}

void Enemy::hit(Vector2 knockback) {
    trans_comp->velocity = Vector2Add(trans_comp->velocity, knockback);
    AudioManager::play_sfx("enemy_hit.mp3", 1, 1, 0.1, 0.8);
    health_comp->hurt(1);
}