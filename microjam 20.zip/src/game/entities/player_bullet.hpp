#ifndef PLAYER_BULLET_H
#define PLAYER_BULLET_H
#include <entity.hpp>
#include <sprites.hpp>
#include <particles.hpp>
#include <transform_component.hpp>
#include <audio.hpp>
#include <area_component.hpp>
#include "border.hpp"
#include "enemy.hpp"

class PlayerBullet: public Entity {
public:
    Sprite sprite;
    TransformComponent* trans_comp;
    float anim;

    float time_left;
    Vector2 start_vel;

    PlayerBullet(Vector2 pos, Vector2 vel);
    void process(float delta);
};

#endif