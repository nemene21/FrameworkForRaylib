#include "player.hpp"

Player::Player():
    Ship(half_res, "player.png", 5),
    move_trail {ParticleSystem("player_move.json")} {
        set_name("Player");

        auto timer_comp = new TimerComponent(this);
        timer_comp->add_timer("reload", 0.2, true);
        timer_comp->get_timer("reload")->finished.connect([this](Entity* ent) {
            can_shoot = true;
        });
        add_component(timer_comp);

        move_trail.z_coord = -1;

        camera = new CameraComponent(this);
        add_component(camera);
        CameraManager::bind_camera(camera->get_camera());

        health_comp->died_signal.connect([this](Entity* ent) {
            AudioManager::play_sfx("player_die.mp3", 1, 1);
            CameraManager::bind_camera(nullptr);
        });
        camera->offset = half_res;

        area_comp->add_layer((int)AreaIndex::PLAYER);
    }

const float player_speed = 100;

void Player::shoot() {
    AudioManager::play_sfx("player_shoot.mp3", 1, 0.8, 0.2, 1);
    can_shoot = false;
    ((TimerComponent*)get_component(CompType::TIMER))->get_timer("reload")->start();

    SceneManager::scene_on->add_entity(
        new PlayerBullet(trans_comp->position, {trans_comp->velocity.x * 2.0f, -500})
    );

    camera->shake(2, 0.1f, -0.5f*PI);
}

void Player::process(float delta) {
    move_trail.update_transform(trans_comp);
    move_trail.scale = {0.33, 0.33};
    move_trail.angle = PI*0.5;

    Vector2 input_dir = InputVectorNormalized(
        "left", "right",
        "up"  , "down"
    );
    trans_comp->interpolate_velocity(Vector2Scale(
        input_dir, player_speed
    ), 20);

    auto border = (Border*)SceneManager::scene_on->get_entity("Border");
    RectangleDraw& rect = border->rect;

    int collides_on_x = 0;
    if (trans_comp->position.x < rect.real_pos().x - rect.width*0.5 + 6) {
        trans_comp->position.x = rect.real_pos().x - rect.width*0.5 + 6;
        collides_on_x++;
    }
    if (trans_comp->position.x > rect.real_pos().x + rect.width*0.5 - 6) {
        trans_comp->position.x = rect.real_pos().x + rect.width*0.5 - 6;
        collides_on_x++;
    }
    if (collides_on_x == 2) {
        health_comp->hurt(9999);
        return;
    }

    if (trans_comp->position.y > res.y) {
        trans_comp->position.y = res.y;
    }
    if (trans_comp->position.y < 0) {
        trans_comp->position.y = 0;
    }

    if (IsPressed("shoot") && can_shoot) {
        shoot();
    }

    sprite.update_transform(trans_comp);
    sprite.angle += trans_comp->velocity.x * 0.15;
}