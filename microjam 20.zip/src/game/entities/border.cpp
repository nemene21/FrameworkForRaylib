#include "border.hpp"

RectangleDraw::RectangleDraw(Vector2 pos, float w, float h): Drawable(pos), width {w}, height {h} {
    z_coord = 10;
    tint = WHITE;
}

void RectangleDraw::draw() {
    float width_calc = (res.x - width)/2.f;
    //DrawRectangle(0, 0,                  width_calc + 2, res.y, BLACK);
    //DrawRectangle(res.x - width_calc - 2, 0, width_calc, res.y, BLACK);

    DrawRectangleLinesEx({
        real_pos().x - width*0.5f,
        real_pos().y - height*0.5f,
        width, height}, 2, WHITE
    );
}

Border::Border(): rect {RectangleDraw({half_res.x, half_res.y}, res.x, res.y)} {
        set_name("Border");
        expansion = 0;
    }

void Border::process(float delta) {
    Entity* player = SceneManager::scene_on->get_entity("Player");
    expansion = Lerpi(expansion, 0, 20);

    if (player != nullptr) {
        rect.width -= delta * 10;
        rect.width += expansion * delta * 200;
    } else {
        rect.width = Lerpi(rect.width, res.x, 30);
    }
    rect.tint = Lerp(WHITE, GRAY, expansion);
    rect.width = fminf(rect.width, res.x);
}

void Border::expand() {
    AudioManager::play_sfx("hit_border.mp3", 1, 1, 0.2, 2);
    expansion = 1;
}