#ifndef BORDER_H
#define BORDER_H
#include <entity.hpp>
#include <drawables.hpp>
#include <scene.hpp>
#include <audio.hpp>

class RectangleDraw: public Drawable {
public:
    float width, height;
    RectangleDraw(Vector2 pos, float w, float h);

    void draw();
};

class Border: public Entity {
public:
    RectangleDraw rect;
    float expansion;
    Border();

    void process(float delta);
    void expand();
};

#endif