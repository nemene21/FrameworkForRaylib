#include "enemy_bullet.hpp"

EnemyBullet::EnemyBullet(Vector2 pos, Vector2 vel):
    sprite {Sprite("enemy_bullet.png")},
    glow {Sprite("glow.png")} {
        trans_comp = new TransformComponent(this, pos);
        trans_comp->velocity = vel;
        add_component(trans_comp);

        trans_comp->scale = {0, 0};

        glow.blend_mode = BLEND_ADDITIVE;
        glow.z_coord = 10;
        glow.tint = {60, 40, 40, 255};

        auto area_comp = new AreaComponent(this, 4);
        area_comp->add_mask_bit((int)AreaIndex::PLAYER);
        area_comp->area_entered.connect([this](Entity* ent) {
            queue_free();
            auto player = (Ship*)SceneManager::scene_on->get_entity("Player");
            player->health_comp->hurt(9999);
        });
        add_component(area_comp);
    }

void EnemyBullet::process(float delta) {
    trans_comp->scale = Lerpi(trans_comp->scale, {1, 1}, 30);

    sprite.update_transform(trans_comp);
    glow.update_transform(trans_comp);

    float scale = 0.135 + sinf(GetTime() * 5) * 0.015;
    glow.scale = Vector2Scale(glow.scale, scale);
}