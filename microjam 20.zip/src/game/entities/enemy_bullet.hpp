#ifndef ENEMY_BULLET_H
#define ENEMY_BULLET_H
#include <entity.hpp>
#include <sprites.hpp>
#include <transform_component.hpp>
#include <area_component.hpp>
#include <scene.hpp>
#include "ship.hpp"

class EnemyBullet: public Entity {
public:
    Sprite sprite;
    Sprite glow;
    TransformComponent* trans_comp;

    EnemyBullet(Vector2 pos, Vector2 vel);
    void process(float delta);
};

#endif