#ifndef SHIP_H
#define SHIP_H
#include <entity.hpp>
#include <transform_component.hpp>
#include <health_component.hpp>
#include <sprites.hpp>
#include <scene.hpp>
#include <particles.hpp>
#include <audio.hpp>
#include <area_component.hpp>

class Ship: public Entity {
public:
    Sprite sprite;
    TransformComponent* trans_comp;
    AreaComponent* area_comp;
    HealthComponent* health_comp;

    Ship(Vector2 position, std::string sprite_texture, int hp);
    void die();
};

#endif