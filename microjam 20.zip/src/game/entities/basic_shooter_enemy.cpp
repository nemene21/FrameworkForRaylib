#include "basic_shooter_enemy.hpp"

BasicShooter::BasicShooter(Vector2 pos): Enemy(pos, "shooter_enemy.png") {
    auto timer_comp = new TimerComponent(this);
    timer_comp->add_timer("shoot", 3, true);
    timer_comp->get_timer("shoot")->progress = RandF()*3;
    timer_comp->get_timer("shoot")->repeat = true;
    timer_comp->get_timer("shoot")->finished.connect([this](Entity* ent) {
        Entity* player = SceneManager::scene_on->get_entity("Player");
        if (player == nullptr) return;
        Vector2 player_pos = ((TransformComponent*)player->get_component(CompType::TRANSFORM))->position;
        Vector2 vel = Vector2Subtract(player_pos, trans_comp->position);
        vel = Vector2Scale(Vector2Normalize(vel), 33);
        vel = Vector2Rotate(vel, RandF2()*PI*0.33f);

        SceneManager::scene_on->add_entity(
            new EnemyBullet(trans_comp->position, vel)
        );

        AudioManager::play_sfx("enemy_shoot.mp3", 1, 1, 0.2, 0.8);
    });
    add_component(timer_comp);
}

void BasicShooter::process(float delta) {
    sprite.update_transform(trans_comp);
    sprite.angle = 180;

    Vector2 ideal_vel = {0, 15};
    trans_comp->interpolate_velocity(ideal_vel, 15);
}