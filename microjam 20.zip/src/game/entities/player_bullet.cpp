#include "player_bullet.hpp"

PlayerBullet::PlayerBullet(Vector2 pos, Vector2 vel):
    sprite {Sprite("player_bullet.png")},
    start_vel {vel} {
        trans_comp = new TransformComponent(this, pos);
        trans_comp->velocity = start_vel;

        anim = 1;
        time_left = 0.2;

        add_component(trans_comp);

        auto area_comp = new AreaComponent(this, 8);
        area_comp->add_mask_bit((int)AreaIndex::ENEMY);
        area_comp->area_entered.connect([this](Entity* ent) {
            auto area = ((AreaComponent*)get_component(CompType::AREA));
            Entity* entered = area->last_entered->entity;

            if (!entered->is_death_queued()) {
                ((Enemy*)entered)->hit(Vector2Scale(trans_comp->velocity, 0.2f));
                SceneManager::scene_on->add_entity(
                    new ParticleEntity("enemy_hit.json", trans_comp->position)
                );
                queue_free();
            }
        });
        add_component(area_comp);
    }

void PlayerBullet::process(float delta) {
    anim = Lerpi(anim, 0, 25);
    sprite.update_transform(trans_comp);
    sprite.angle = -90 + trans_comp->velocity.x * 0.2;

    sprite.scale = Lerp(Vector2{1, 1}, Vector2{1.5, 1.5}, anim);
    time_left -= delta;

    if (time_left < 0) {
        queue_free();
        return;
    }
    float blend = 1.f-time_left/.2f;
    blend *= blend;
    trans_comp->velocity = Lerp(start_vel, {0, 0}, blend);

    sprite.scale = Vector2Scale(sprite.scale, 1.f - blend*blend);

    auto border = (Border*)SceneManager::scene_on->get_entity("Border");
    if (abs(half_res.x - trans_comp->position.x) > border->rect.width * 0.5f) {
        border->expand();
        queue_free();
    }

    if (trans_comp->position.y < -16) {
        queue_free();
    }
}