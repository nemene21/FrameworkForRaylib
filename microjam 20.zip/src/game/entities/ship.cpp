#include "ship.hpp"

Ship::Ship(Vector2 position, std::string sprite_texture, int hp):
    sprite {Sprite(sprite_texture)}
     {
    trans_comp = new TransformComponent(this, position);
    add_component(trans_comp);

    area_comp = new AreaComponent(this, 4);
    add_component(area_comp);

    health_comp = new HealthComponent(this, hp);
    health_comp->died_signal.connect([this](Entity* ent) {
        die();
    });
    add_component(health_comp);
}

void Ship::die() {
    SceneManager::scene_on->add_entity(
        new ParticleEntity("ship_explode.json", trans_comp->position)
    );
    SceneManager::scene_on->add_entity(
        new ParticleEntity("bolts.json", trans_comp->position)
    );
    queue_free();
}