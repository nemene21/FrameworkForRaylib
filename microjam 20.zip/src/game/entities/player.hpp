#ifndef PLAYER_H
#define PLAYER_H
#include "ship.hpp"
#include "border.hpp"
#include <input.hpp>
#include <scene.hpp>
#include <timer_component.hpp>
#include <camera_component.hpp>
#include "player_bullet.hpp"

class Player: public Ship {
public:
    ParticleSystem move_trail;
    CameraComponent* camera;
    bool can_shoot;
    Player();

    void process(float delta);
    void shoot();
};

#endif