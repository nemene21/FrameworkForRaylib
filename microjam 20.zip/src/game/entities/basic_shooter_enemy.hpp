#ifndef BASIC_SHOOTER_ENEMY_H
#define BASIC_SHOOTER_ENEMY_H
#include "enemy.hpp"
#include "enemy_bullet.hpp"
#include <timer_component.hpp>
#include <misc.hpp>

class BasicShooter: public Enemy {
public:
    BasicShooter(Vector2 pos);

    void process(float delta);
};

#endif