#ifndef SCORE_H
#define SCORE_H
#include <drawables.hpp>
#include <sprites.hpp>
#include <scene.hpp>

class ScoreCounter: public Drawable {
public:
    int score, highscore, wave;
    float wave_anim;
    float death_anim;
    char *msg;
    ScoreCounter();
    void draw();

};

#endif