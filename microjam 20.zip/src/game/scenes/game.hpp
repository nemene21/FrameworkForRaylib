#ifndef GAME_H
#define GAME_H
#include <scene.hpp>
#include <entities/player.hpp>
#include <entities/border.hpp>
#include <entities/basic_shooter_enemy.hpp>
#include "score_counter.hpp"

class GameScene: public Scene {
public:
    int score, highscore, display_score, wave, enemy_count;
    GameScene();

    ParticleSystem bg;
    
    ScoreCounter score_counter;

    void restart();
    void enemy_died();
    void new_wave();
    void process(float delta);
};

#endif