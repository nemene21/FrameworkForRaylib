#include "score_counter.hpp"

ScoreCounter::ScoreCounter() {
    score = 0;
    highscore = 0;
    death_anim = 0;
    wave = 1;
    msg = (char*)("Space to play");
}

void ScoreCounter::draw() {
    // Score
    int fontsize = 20;
    char *score_text = (char *)std::to_string(score).c_str();
    float width = MeasureText(score_text, fontsize) * 0.5f;
    DrawText(score_text, half_res.x - width, half_res.y - 32, fontsize, GRAY);
    // Highscore
    score_text = (char *)std::to_string(highscore).c_str();
    width = MeasureText(score_text, fontsize) * 0.5f;
    DrawText(score_text, half_res.x - width, half_res.y + 32, fontsize, GRAY);

    float offset = highscore == score ? sinf(GetTime()*5.f) * 3 : 0;
    DrawTextureCentered(TextureManager::get("crown.png").get(), {90, half_res.y + 20 + offset});

    // Wave
    char *wave_text = (char*)malloc(5 + floor(log10(wave))+1);
    sprintf(wave_text, "Cycle %i", wave);
    width = MeasureText(wave_text, fontsize) * 0.5f;

    wave_anim -= GetFrameTime();
    if (wave_anim < 0) wave_anim = 0;
    float anim = sinf(wave_anim * PI);
    float angle = fminf(1, anim / 0.5f) * 18 - 18;

    DrawTextPro(GetFontDefault(), wave_text, {
        half_res.x, 32
    }, {width, fontsize * 0.5f}, angle, fontsize, 2, {
        GRAY.r, GRAY.g, GRAY.b, (unsigned char)(fminf(255, 255 * anim * 5))
    });

    Entity* player = SceneManager::scene_on->get_entity("Player");
    if (player == nullptr) {
        death_anim += GetFrameTime();
        if (death_anim > 1) death_anim = 1;
    } else {
        death_anim -= GetFrameTime();
        if (death_anim < 0) death_anim = 0;
    }

    score_text = msg;
    fontsize = 10;
    width = MeasureText(score_text, fontsize) * 0.5f;
    DrawText(score_text, half_res.x - width, res.y - 32 + 64*(1-death_anim), fontsize, GRAY);
}