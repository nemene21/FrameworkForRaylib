#include "game.hpp"

GameScene::GameScene(): Scene("game_scene"), bg {ParticleSystem("bg.json")} {
    wave = 0;
    score = 0;
    highscore = 0;
    display_score = 0;

    score_counter = ScoreCounter();

    bg.position.x = half_res.x;
    bg.position.y = - 64;

    AudioManager::play_track("lose.mp3", 0.2f);
}

void GameScene::restart() {
    add_entity(new Border());
}

void GameScene::enemy_died() {
    enemy_count--;
    score += 100;

    if (score > highscore) {
        highscore = score;
    }

    score_counter.score = score;
    score_counter.highscore = highscore;

    if (enemy_count <= 0) {
        new_wave();
    }
}

void GameScene::process(float delta) {
    Entity* player = get_entity("Player");

    for (Entity* enemy: query_in_group("Enemy")) {
        auto trans_comp = (TransformComponent*)enemy->get_component(CompType::TRANSFORM);
        if (trans_comp->position.y > res.y + 24 || player == nullptr) {
            ((HealthComponent*)enemy->get_component(CompType::HEALTH))->hurt(9999);
            score -= 100;
        }
    }

    if (player == nullptr && IsJustPressed("jump")) {
        player = new Player();
        auto hp_comp = (HealthComponent*)player->get_component(CompType::HEALTH);

        add_entity(player);
        score = 0;
        wave = 0;
        score_counter.score = 0;

        hp_comp->died_signal.connect([this](Entity* ent) {
            score_counter.msg = "Space to play again";
            AudioManager::play_track("lose.mp3", 0.2f);
        });
        AudioManager::play_track("battle.mp3", 0.2f);
        new_wave();
    }
}

void GameScene::new_wave() {
    if (get_entity("Player") == nullptr) return;

    AudioManager::play_sfx("wave_start.mp3");

    wave++;
    enemy_count = (int)powf(wave * 1.5, 1.1);

    score_counter.wave = wave;
    score_counter.wave_anim = 1;

    for (int i = 0; i < enemy_count; i++) {
        Enemy* enemy = new BasicShooter({RandF() * res.x, -16 - RandF() * res.y * 0.5f});
        enemy->health_comp->died_signal.connect([this](Entity* ent) {
            enemy_died();
        });
        add_entity(enemy);
    }    
}